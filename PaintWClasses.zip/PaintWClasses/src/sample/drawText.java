package sample;

import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.HBox;

import java.awt.*;

public class drawText extends HBox {

    drawText(Canvas canvas, GraphicsContext gc, double x, double y){
        TextField myText = new TextField();
        HBox textBox = new HBox();
        //textBox.getChildren().add();



    }

}
