package sample;

import javafx.event.EventHandler;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class myCanvas extends Canvas {
    public String lineType;

    myCanvas(Canvas canvas, GraphicsContext gc, double realWidth, double realHeight, String lineType){


    }
    public void setLineType(String type){
        lineType = type;
    }
}
